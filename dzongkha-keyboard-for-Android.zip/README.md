# dzongkha-keyboard-cst
android dzongkha keyboard full source code 

The app was developed by final year students of College of Science and Technology with support from Dzongkha Development Comission. 


![Screen Shot 2022-01-28 at 9 09 35 PM](https://user-images.githubusercontent.com/71761992/151746693-0ff13ca2-0801-4d22-9799-e66ae475bd99.png)
![Screen Shot 2022-01-28 at 9 10 55 PM](https://user-images.githubusercontent.com/71761992/151747226-f428a24f-cc71-4865-b301-57aef5545b6e.png)
![Screen Shot 2022-01-28 at 9 11 51 PM](https://user-images.githubusercontent.com/71761992/151746766-f5982d65-a94c-4810-8694-cefb781743be.png)
![Screen Shot 2022-01-28 at 9 27 43 PM](https://user-images.githubusercontent.com/71761992/151746913-e798444c-22fb-4de1-a990-e4e969e6f52b.png)
![Screen Shot 2022-01-28 at 9 25 06 PM](https://user-images.githubusercontent.com/71761992/151746923-ac91aaeb-582c-49e8-8865-cd3fa9e5a7c1.png)
![Screen Shot 2022-01-28 at 9 29 46 PM](https://user-images.githubusercontent.com/71761992/151746928-7c0f3cb4-cdc1-4a51-853b-235d33bd6ffc.png)
